<?php
$page_heading = "Server Error";
$page_content = '<p class="connectFailp" >Sorry our servers seems to be experiencing some technical difficulties. Please check back later.<p>';
?>

<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/template.php'; ?>