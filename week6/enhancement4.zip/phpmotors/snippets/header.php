<div id="top-header">
    <a href="/phpmotors/index.php">
        <img src="/phpmotors/images/site/logo.png" id="logo" alt="PHP Motors logo">
    </a>
    <a href="/phpmotors/accounts/index.php?action=login" title="log in or create account" id="myaccount">My Account</a>
</div>