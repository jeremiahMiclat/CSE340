<!-- main content template-->
<?php ob_start(); ?>
<section id="search">
    <?php
    if (isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }
    ?>
    <form id="searchBox" method="POST">
        <input id="searching" type="text" name="search" required>
        <label for="searching">Search Box</label>
        <input type="submit" name="submit" id="searchbtn" value="Search">
        <!-- Add the action name - value pair -->
        <input type="hidden" name="action" value="search">



    </form>
    <?php

    // echo '<p>' . $item . '</p>';
    // echo '<p>' . $page . '</p>';
    // if (isset($searchResults)) {
    //     echo $searchResults;

    //     foreach ($pagesLinks as $item) {
    //         echo "<br>$item <br>";
    //     }
    // }

    // if (isset($item)) {
    //     echo "<p>Page " . $page . " of about ". $searchCount ." results</p>";
    // }

    
    if (isset($_SESSION['notif'])) {
        echo $_SESSION['notif'];
        unset($_SESSION['notif']);
    }
    


    if (isset($itemLinks)) {
        echo $itemLinks;
    }

    if (isset($paginationDisplay)) {
        echo $paginationDisplay;
        
    }

    ?>
</section>

<!-- variables for template -->
<?php
$page_heading = "Search";
$page_content = ob_get_clean();

?>

<!-- template call -->
<?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/view/template.php'; ?>

<?php unset($_SESSION['message']); ?>
<?php unset($_SESSION['notif']); ?>