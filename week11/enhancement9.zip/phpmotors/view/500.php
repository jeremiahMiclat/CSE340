<?php
$page_heading = "Server Error";
$page_content = '<p class="left30px bottom30px" >Sorry our servers seems to be experiencing some technical difficulties. Please check back later.<p>';
?>

<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/view/template.php'; ?>