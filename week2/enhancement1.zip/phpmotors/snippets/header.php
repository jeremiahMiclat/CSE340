<div id="top-header">
    <a href="#">
        <img src="/phpmotors/images/site/logo.png" id="logo" alt="PHP Motors logo">
    </a>
    <a href="#" title="log in or create account" id="myaccount">My Account</a>
</div>